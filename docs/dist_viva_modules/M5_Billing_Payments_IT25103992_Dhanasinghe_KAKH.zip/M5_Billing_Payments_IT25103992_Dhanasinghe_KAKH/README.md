# PulseOS — Viva Technical Defense & Module Source Code Dossier
## SLIIT SE2030 Software Engineering Project — Batch 02 | Group 60
### Academic Year 2026 | Year 2 Semester 1

---

### Student Information:
- **Full Name**: `Dhanasinghe K. A. K. H.`
- **Preferred Name**: `Kesaru`
- **Student ID (IT Number)**: `IT25103992`
- **Official SLIIT Email**: `it25103992@my.sliit.lk`
- **Assigned Major Function**: **M5: Multi-Department Itemized Invoicing, Counter Settlement & PayHere Sandbox Gateway**
- **Dedicated Git Branch**: `feature/billing-payment`
- **Production URL**: `https://pulseos.tekkeys.com`
- **Database Web Interface (Adminer)**: `https://pulseos.tekkeys.com/adminer`

---

## 1. Assigned Design Pattern: Adapter Pattern (PayHere Sandbox 3D-Secure Payment Adapter & Counter Cash Settlement)

### Why This Pattern Was Chosen & How It Works:
We applied the **Adapter Pattern** to unify disparate payment mechanisms behind a common payment interface. The system supports both local In-Person Cashier Settlement (Cash, POS Card Terminal) and the third-party **PayHere Online Payment Gateway** (Central Bank approved 3D-Secure with MD5 cryptographic signatures and asynchronous IPN callbacks). The Adapter converts heterogeneous payment request and response payloads into a standardized `PaymentTransaction` domain entity.

> **Viva Tip**: When the lecturer asks: *"What design pattern did you use in your individual module?"*  
> Confidently answer: *"In my module (Multi-Department Itemized Invoicing, Counter Settlement & PayHere Sandbox Gateway), I implemented the **Adapter Pattern**. Let me show you exactly where in my code it is located..."*

---

## 2. Complete CRUD Implementation Map

Every team member is evaluated on having complete **CRUD (Create, Read, Update, Delete)** functionality in both the **Backend (Java Spring Boot)** and **Frontend (React TypeScript)**, connected to a live database.

| Operation | Action Description | Backend Location (Controller & Service) | Frontend UI Component | Database SQL Executed |
| :--- | :--- | :--- | :--- | :--- |
| **CREATE** | Compile aggregated multi-department invoice combining Doctor, Pharmacy, and Laboratory fees | `BillingController.java -> @PostMapping("/invoices") generateInvoice() | BillingService.java -> generateInvoice()` | `BillingView.tsx -> handleGenerateInvoice() & 'Generate Invoice' Modal` | `INSERT INTO invoice (invoice_number, total_amount, doctor_fee, pharmacy_fee, lab_fee, payment_status) VALUES (...)` |
| **READ** | Review invoices, itemized tariff breakdowns, filter by Paid/Pending, and inspect payment transactions | `BillingController.java -> @GetMapping("/invoices") getAllInvoices() & @GetMapping("/invoices/{id}")` | `BillingView.tsx -> DataTable with Paid/Pending filter & SlideOverDrawer breakdown` | `SELECT * FROM invoice ORDER BY id DESC` |
| **UPDATE** | Apply clinical concessions/discounts (Senior Citizen, Staff, Welfare) OR settle via Cashier counter / PayHere Gateway | `BillingController.java -> @PutMapping("/invoices/{id}") updateInvoice() & @PostMapping("/invoices/{id}/settle") settleInvoice()` | `BillingView.tsx -> 'Discount' button opening Apply Concession Modal & 'Cashier' settle button` | `UPDATE invoice SET discount_amount = ?, discount_reason = ?, net_amount = ? WHERE id = ?; UPDATE invoice SET payment_status = 'PAID'` |
| **DELETE** | Void / cancel incorrect invoice with audit trail preservation | `BillingController.java -> @DeleteMapping("/invoices/{id}") cancelInvoice() | BillingService.java -> cancelInvoice()` | `BillingView.tsx -> 'Void Bill' trash button opening Confirmation Modal` | `UPDATE invoice SET payment_status = 'CANCELLED' WHERE id = ?` |

---

## 3. Step-by-Step Live Viva Demonstration Script

Follow this exact sequence on your screen when demonstrating to the lecturer:
1. Open **Billing & Cashier Station** (`https://pulseos.tekkeys.com/billing`).
2. Demonstrate CREATE: Click **'Generate Invoice'**, select a patient (e.g. Kamal Perera), enter doctor fee (`LKR 2,500`), pharmacy fee (`LKR 1,850`), lab fee (`LKR 3,200`) -> Click **Generate Bill** -> Show `INV-XXXXXX` created with Total `LKR 7,550.00`.
3. Demonstrate UPDATE (Discount / Concession): On the pending invoice, click **'Discount'** -> select **'Senior Citizen (10%)'** or enter custom concession -> Show live calculation preview -> Click **'Save & Update Bill'** -> Show the table immediately reflecting adjusted Net Due!
4. Demonstrate UPDATE (Settlement): Click **'Cashier'** -> Confirm cash settlement -> Show status flipping to `PAID` with green check badge.
5. Demonstrate PayHere Gateway: Click **'PayHere'** button -> Show encrypted checkout modal with PayHere Merchant ID `1235909` -> Explain MD5 checksum generation and IPN callback verification.
6. Demonstrate DELETE (Void): Click the trash icon on a test pending invoice -> Confirm Void -> Show status updated to `CANCELLED`.
7. Open Adminer (`https://pulseos.tekkeys.com/adminer`) and run SQL query on `invoice` table to prove real-time persistence!

---

## 4. Live Database Verification Query

Keep **Adminer** (`https://pulseos.tekkeys.com/adminer`) or your local MySQL client open. Run this SQL query to show the lecturer that your data is actively persisting:

```sql
-- Database: pulseos_db
SELECT id, invoice_number, total_amount, discount_amount, net_amount, payment_status, billing_date FROM invoice ORDER BY id DESC LIMIT 5;
```

---

## 5. High-Probability Viva Questions & Model Answers

### Q1: How does your multi-item invoice aggregation work across different hospital departments?
> **Answer**: In `BillingService.generateInvoice()`, we aggregate clinical costs across three departments: (1) Attending Doctor's professional consultation fee, (2) Dispensed pharmacy medications (`sum(unitPrice * quantity)` from Harshika's module), and (3) Ordered laboratory pathology investigations (from Nethuli's module). The gross total is `doctorFee + pharmacyFee + labFee`, from which any authorized discount/concession is deducted to yield `netAmount`.

### Q2: Explain the security of your PayHere Sandbox payment integration.
> **Answer**: Our PayHere integration complies with Central Bank of Sri Lanka 3D-Secure standards. Before checkout opens, `PayHereSecurityUtil` calculates an MD5 checksum: `hash = md5(merchant_id + order_id + formatted_amount + currency + md5(merchant_secret)).toUpperCase()`. When PayHere dispatches its signed server-to-server IPN webhook to `/api/v1/payments/payhere/notify`, our backend recalculates the expected signature. Only if the signature matches 100% does the system mark the invoice as `PAID`, preventing client-side price tampering.

### Q3: Why did you implement both Cashier Counter Settlement and Online PayHere?
> **Answer**: A realistic hospital serves diverse patient demographics. Elderly or emergency outpatients frequently pay in cash or via local hospital POS card terminal at the discharge desk, while digitally savvy patients use the online Patient Portal with PayHere to settle bills remotely via Credit Card, Debit Card, or Mobile Wallets.


---

## 6. Included Source Code Files in This Folder

### Backend Java Files (`backend/`):
- `Invoice.java`
- `InvoiceDrugItem.java`
- `InvoiceLabItem.java`
- `PaymentTransaction.java`
- `PaymentMethod.java`
- `PaymentStatus.java`
- `InvoiceRepository.java`
- `PaymentRepository.java`
- `BillingService.java`
- `BillingController.java`
- `PaymentController.java`
- `PayHereConfig.java`
- `PayHereSecurityUtil.java`
- `BillingDTOs.java`

### Frontend React Files (`frontend/`):
- `BillingView.tsx`
- `PatientPortalView.tsx`

---
*Generated for SLIIT SE2030 Group 60 Evaluation | PulseOS Hospital Management System*
